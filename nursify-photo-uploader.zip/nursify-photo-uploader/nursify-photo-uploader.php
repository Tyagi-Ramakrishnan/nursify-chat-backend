<?php
/**
 * Plugin Name: Nursify Photo Uploader
 * Description: Admin tool for Thanisha to upload result photos — sets image, Instagram URL, procedure type, and auto-updates photo-grid & photo-library in the Nursify theme.
 * Version:     1.0.0
 * Author:      Nursify Aesthetics
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ============================================================
// 1. CUSTOM POST TYPE: nursify_result
// ============================================================
add_action( 'init', function () {
    register_post_type( 'nursify_result', [
        'labels'       => [
            'name'          => 'Result Photos',
            'singular_name' => 'Result Photo',
            'add_new_item'  => 'Add New Result Photo',
            'edit_item'     => 'Edit Result Photo',
            'all_items'     => 'All Result Photos',
        ],
        'public'       => false,
        'show_ui'      => true,
        'show_in_rest' => true,
        'show_in_menu' => true,
        'menu_icon'    => 'dashicons-camera',
        'supports'     => [ 'title', 'thumbnail' ],
    ] );
} );

// ============================================================
// 1b. REGISTER META FOR REST API
// ============================================================
add_action( 'init', function () {
    $meta_fields = [
        '_nursify_instagram_url'  => 'string',
        '_nursify_procedure_type' => 'string',
        '_nursify_show_on_home'   => 'string',
    ];
    foreach ( $meta_fields as $key => $type ) {
        register_post_meta( 'nursify_result', $key, [
            'show_in_rest'  => true,
            'single'        => true,
            'type'          => $type,
            'auth_callback' => function() { return current_user_can('edit_posts'); },
        ] );
    }
} );

// ============================================================
// 2. META BOXES
// ============================================================
add_action( 'add_meta_boxes', function () {
    add_meta_box(
        'nursify_result_meta',
        'Photo Details',
        'nursify_result_meta_box_html',
        'nursify_result',
        'normal',
        'high'
    );
} );

function nursify_result_meta_box_html( $post ) {
    wp_nonce_field( 'nursify_result_save', 'nursify_result_nonce' );

    $instagram_url   = get_post_meta( $post->ID, '_nursify_instagram_url', true );
    $procedure_type  = get_post_meta( $post->ID, '_nursify_procedure_type', true );
    $show_on_home    = get_post_meta( $post->ID, '_nursify_show_on_home', true );

    $procedures = nursify_get_procedure_types();
    ?>
    <style>
        .nursify-meta-table { width:100%; border-collapse:collapse; }
        .nursify-meta-table th { text-align:left; padding:10px 10px 4px 0; font-weight:600; color:#3c3c3c; width:160px; }
        .nursify-meta-table td { padding:6px 0 12px 0; }
        .nursify-meta-table input[type=text], .nursify-meta-table select {
            width:100%; max-width:500px; padding:8px 10px;
            border:1px solid #ccd0d4; border-radius:4px; font-size:14px;
        }
        .nursify-meta-table input[type=text]:focus, .nursify-meta-table select:focus {
            border-color: #7c3f6e; box-shadow: 0 0 0 1px #7c3f6e; outline:none;
        }
        .nursify-preview-wrap { margin-top:8px; }
        .nursify-preview-wrap img { max-width:200px; border-radius:6px; border:2px solid #e0c9d8; }
        .nursify-thumb-btn { margin-top:6px !important; }
        .nursify-hint { color:#888; font-size:12px; margin-top:4px; }
    </style>

    <table class="nursify-meta-table">
        <tr>
            <th><label>Display Image</label></th>
            <td>
                <?php
                $thumb_id = get_post_thumbnail_id( $post->ID );
                $thumb_url = $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'medium' ) : '';
                ?>
                <div class="nursify-preview-wrap" id="nursify-thumb-preview">
                    <?php if ( $thumb_url ) : ?>
                        <img src="<?php echo esc_url($thumb_url); ?>" alt="Current thumbnail">
                    <?php endif; ?>
                </div>
                <input type="hidden" id="nursify-thumbnail-id" name="nursify_thumbnail_id"
                       value="<?php echo esc_attr( $thumb_id ); ?>">
                <button type="button" class="button nursify-thumb-btn" id="nursify-upload-btn">
                    <?php echo $thumb_id ? 'Change Image' : 'Upload / Select Image'; ?>
                </button>
                <p class="nursify-hint">This is the image shown in the photo grid on the website.</p>
            </td>
        </tr>
        <tr>
            <th><label for="nursify_instagram_url">Instagram URL</label></th>
            <td>
                <input type="text" id="nursify_instagram_url" name="nursify_instagram_url"
                       value="<?php echo esc_url( $instagram_url ); ?>"
                       placeholder="https://www.instagram.com/p/XXXXXXX/">
                <p class="nursify-hint">Paste the full Instagram post link. Clicking the photo on the website will open this.</p>
            </td>
        </tr>
        <tr>
            <th><label for="nursify_procedure_type">Procedure Type</label></th>
            <td>
                <select id="nursify_procedure_type" name="nursify_procedure_type">
                    <option value="">— Select a procedure —</option>
                    <?php foreach ( $procedures as $key => $label ) : ?>
                        <option value="<?php echo esc_attr($key); ?>"
                            <?php selected( $procedure_type, $key ); ?>>
                            <?php echo esc_html($label); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
        <tr>
            <th><label for="nursify_show_on_home">Show on Homepage?</label></th>
            <td>
                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                    <input type="checkbox" id="nursify_show_on_home" name="nursify_show_on_home"
                           value="1" <?php checked( $show_on_home, '1' ); ?>>
                    <span>Yes — include this photo in the homepage photo grid</span>
                </label>
                <p class="nursify-hint">Uncheck to show only on service-specific pages.</p>
            </td>
        </tr>
    </table>

    <script>
    jQuery(function($){
        var frame;
        $('#nursify-upload-btn').on('click', function(e){
            e.preventDefault();
            if ( frame ) { frame.open(); return; }
            frame = wp.media({
                title: 'Select Result Photo',
                button: { text: 'Use this photo' },
                multiple: false
            });
            frame.on('select', function(){
                var att = frame.state().get('selection').first().toJSON();
                $('#nursify-thumbnail-id').val(att.id);
                var preview = att.sizes && att.sizes.medium ? att.sizes.medium.url : att.url;
                $('#nursify-thumb-preview').html('<img src="'+preview+'" alt="Selected photo">');
                $('#nursify-upload-btn').text('Change Image');
            });
            frame.open();
        });
    });
    </script>
    <?php
}

// ============================================================
// 3. SAVE META
// ============================================================
add_action( 'save_post_nursify_result', function ( $post_id ) {
    if ( ! isset( $_POST['nursify_result_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['nursify_result_nonce'], 'nursify_result_save' ) ) return;
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    // Thumbnail
    if ( isset( $_POST['nursify_thumbnail_id'] ) && ! empty( $_POST['nursify_thumbnail_id'] ) ) {
        set_post_thumbnail( $post_id, absint( $_POST['nursify_thumbnail_id'] ) );
    }

    // Instagram URL
    if ( isset( $_POST['nursify_instagram_url'] ) ) {
        update_post_meta( $post_id, '_nursify_instagram_url', esc_url_raw( $_POST['nursify_instagram_url'] ) );
    }

    // Procedure type
    if ( isset( $_POST['nursify_procedure_type'] ) ) {
        $allowed = array_keys( nursify_get_procedure_types() );
        $val = sanitize_text_field( $_POST['nursify_procedure_type'] );
        if ( in_array( $val, $allowed, true ) ) {
            update_post_meta( $post_id, '_nursify_procedure_type', $val );
        }
    }

    // Show on homepage
    $show = isset( $_POST['nursify_show_on_home'] ) ? '1' : '0';
    update_post_meta( $post_id, '_nursify_show_on_home', $show );
} );

// ============================================================
// 4. ENQUEUE WP MEDIA on our CPT edit screen
// ============================================================
add_action( 'admin_enqueue_scripts', function ( $hook ) {
    global $post;
    if ( ( $hook === 'post.php' || $hook === 'post-new.php' )
         && isset( $post->post_type ) && $post->post_type === 'nursify_result' ) {
        wp_enqueue_media();
    }
} );

// ============================================================
// 5. PROCEDURE TYPE REGISTRY
// Edit this list to add/remove procedure options
// ============================================================
function nursify_get_procedure_types() {
    return [
        'botox'          => 'Botox / Wrinkle Relaxers',
        'fillers'        => 'Dermal Fillers',
        'lip-filler'     => 'Lip Filler',
        'microneedling'  => 'Microneedling',
        'wellness'       => 'Wellness Injections',
        'weight-loss'    => 'Medical Weight Loss',
        'prf-hair'       => 'PRF Hair Restoration',
        'skincare'       => 'Skincare',
        'reviews'        => 'Client Reviews / Testimonials',
        'events'         => 'Events / Brand',
        'general'        => 'General / Brand',
    ];
}

// ============================================================
// 6. PUBLIC QUERY FUNCTION
// Used by photo-grid.php and photo-library.php to pull photos
// from the database instead of hardcoded arrays.
//
// Usage: $photos = nursify_get_result_photos('botox', 20, true);
//   $tag        = procedure slug or '' for all
//   $limit      = max photos to return (0 = all)
//   $home_only  = true to only get homepage photos
// ============================================================
function nursify_get_result_photos( $tag = '', $limit = 0, $home_only = false ) {
    $meta_query = [];

    if ( $home_only ) {
        $meta_query[] = [
            'key'   => '_nursify_show_on_home',
            'value' => '1',
        ];
    }

    if ( $tag ) {
        $meta_query[] = [
            'key'   => '_nursify_procedure_type',
            'value' => sanitize_text_field( $tag ),
        ];
    }

    $args = [
        'post_type'      => 'nursify_result',
        'post_status'    => 'publish',
        'posts_per_page' => $limit > 0 ? $limit : -1,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'meta_query'     => $meta_query,
    ];

    $results = get_posts( $args );
    $photos  = [];

    foreach ( $results as $post ) {
        $src = get_the_post_thumbnail_url( $post->ID, 'large' );
        if ( ! $src ) continue;

        $photos[] = [
            'src'  => $src,
            'alt'  => get_the_title( $post->ID ),
            'url'  => get_post_meta( $post->ID, '_nursify_instagram_url', true ),
            'tags' => [ get_post_meta( $post->ID, '_nursify_procedure_type', true ) ],
        ];
    }

    return $photos;
}

// ============================================================
// 7. ADMIN COLUMNS — makes the CPT list more useful
// ============================================================
add_filter( 'manage_nursify_result_posts_columns', function ( $cols ) {
    return [
        'cb'            => $cols['cb'],
        'thumbnail'     => 'Photo',
        'title'         => 'Title / Alt Text',
        'procedure'     => 'Procedure',
        'homepage'      => 'Homepage',
        'instagram'     => 'Instagram',
        'date'          => 'Added',
    ];
} );

add_action( 'manage_nursify_result_posts_custom_column', function ( $col, $post_id ) {
    switch ( $col ) {
        case 'thumbnail':
            $url = get_the_post_thumbnail_url( $post_id, 'thumbnail' );
            if ( $url ) echo '<img src="' . esc_url($url) . '" style="width:60px;height:60px;object-fit:cover;border-radius:4px;">';
            break;
        case 'procedure':
            $types = nursify_get_procedure_types();
            $val   = get_post_meta( $post_id, '_nursify_procedure_type', true );
            echo isset($types[$val]) ? esc_html($types[$val]) : '—';
            break;
        case 'homepage':
            $show = get_post_meta( $post_id, '_nursify_show_on_home', true );
            echo $show === '1' ? '<span style="color:green;">✓</span>' : '<span style="color:#ccc;">—</span>';
            break;
        case 'instagram':
            $ig = get_post_meta( $post_id, '_nursify_instagram_url', true );
            if ( $ig ) echo '<a href="' . esc_url($ig) . '" target="_blank" rel="noopener">View ↗</a>';
            break;
    }
}, 10, 2 );
